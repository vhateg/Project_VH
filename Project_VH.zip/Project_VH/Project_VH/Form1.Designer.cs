﻿namespace Project_VH
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Num11 = new System.Windows.Forms.Label();
            this.Num12 = new System.Windows.Forms.Label();
            this.Num13 = new System.Windows.Forms.Label();
            this.Num14 = new System.Windows.Forms.Label();
            this.Num24 = new System.Windows.Forms.Label();
            this.Num23 = new System.Windows.Forms.Label();
            this.Num22 = new System.Windows.Forms.Label();
            this.Num21 = new System.Windows.Forms.Label();
            this.Num34 = new System.Windows.Forms.Label();
            this.Num33 = new System.Windows.Forms.Label();
            this.Num32 = new System.Windows.Forms.Label();
            this.Num31 = new System.Windows.Forms.Label();
            this.Num44 = new System.Windows.Forms.Label();
            this.Num43 = new System.Windows.Forms.Label();
            this.Num42 = new System.Windows.Forms.Label();
            this.Num41 = new System.Windows.Forms.Label();
            this.arena = new System.Windows.Forms.GroupBox();
            this.scoreLabel = new System.Windows.Forms.Label();
            this.startButton = new System.Windows.Forms.Button();
            this.highScoreLabel = new System.Windows.Forms.Label();
            this.downButton = new System.Windows.Forms.Button();
            this.rightButton = new System.Windows.Forms.Button();
            this.leftButton = new System.Windows.Forms.Button();
            this.upButton = new System.Windows.Forms.Button();
            this.arena.SuspendLayout();
            this.SuspendLayout();
            // 
            // Num11
            // 
            this.Num11.AutoSize = true;
            this.Num11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num11.ForeColor = System.Drawing.Color.Maroon;
            this.Num11.Location = new System.Drawing.Point(6, 28);
            this.Num11.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num11.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num11.Name = "Num11";
            this.Num11.Size = new System.Drawing.Size(49, 18);
            this.Num11.TabIndex = 0;
            this.Num11.Text = " 0000";
            this.Num11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num12
            // 
            this.Num12.AutoSize = true;
            this.Num12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num12.ForeColor = System.Drawing.Color.Maroon;
            this.Num12.Location = new System.Drawing.Point(61, 28);
            this.Num12.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num12.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num12.Name = "Num12";
            this.Num12.Size = new System.Drawing.Size(49, 18);
            this.Num12.TabIndex = 1;
            this.Num12.Text = " 0000";
            this.Num12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num13
            // 
            this.Num13.AutoSize = true;
            this.Num13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num13.ForeColor = System.Drawing.Color.Maroon;
            this.Num13.Location = new System.Drawing.Point(116, 28);
            this.Num13.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num13.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num13.Name = "Num13";
            this.Num13.Size = new System.Drawing.Size(49, 18);
            this.Num13.TabIndex = 2;
            this.Num13.Text = " 0000";
            this.Num13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num14
            // 
            this.Num14.AutoSize = true;
            this.Num14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num14.ForeColor = System.Drawing.Color.Maroon;
            this.Num14.Location = new System.Drawing.Point(171, 28);
            this.Num14.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num14.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num14.Name = "Num14";
            this.Num14.Size = new System.Drawing.Size(49, 18);
            this.Num14.TabIndex = 3;
            this.Num14.Text = " 0000";
            this.Num14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num24
            // 
            this.Num24.AutoSize = true;
            this.Num24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num24.ForeColor = System.Drawing.Color.Maroon;
            this.Num24.Location = new System.Drawing.Point(171, 57);
            this.Num24.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num24.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num24.Name = "Num24";
            this.Num24.Size = new System.Drawing.Size(49, 18);
            this.Num24.TabIndex = 7;
            this.Num24.Text = " 0000";
            this.Num24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num23
            // 
            this.Num23.AutoSize = true;
            this.Num23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num23.ForeColor = System.Drawing.Color.Maroon;
            this.Num23.Location = new System.Drawing.Point(116, 57);
            this.Num23.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num23.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num23.Name = "Num23";
            this.Num23.Size = new System.Drawing.Size(49, 18);
            this.Num23.TabIndex = 6;
            this.Num23.Text = " 0000";
            this.Num23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num22
            // 
            this.Num22.AutoSize = true;
            this.Num22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num22.ForeColor = System.Drawing.Color.Maroon;
            this.Num22.Location = new System.Drawing.Point(61, 57);
            this.Num22.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num22.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num22.Name = "Num22";
            this.Num22.Size = new System.Drawing.Size(49, 18);
            this.Num22.TabIndex = 5;
            this.Num22.Text = " 0000";
            this.Num22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num21
            // 
            this.Num21.AutoSize = true;
            this.Num21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num21.ForeColor = System.Drawing.Color.Maroon;
            this.Num21.Location = new System.Drawing.Point(6, 57);
            this.Num21.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num21.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num21.Name = "Num21";
            this.Num21.Size = new System.Drawing.Size(49, 18);
            this.Num21.TabIndex = 4;
            this.Num21.Text = " 0000";
            this.Num21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num34
            // 
            this.Num34.AutoSize = true;
            this.Num34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num34.ForeColor = System.Drawing.Color.Maroon;
            this.Num34.Location = new System.Drawing.Point(171, 85);
            this.Num34.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num34.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num34.Name = "Num34";
            this.Num34.Size = new System.Drawing.Size(49, 18);
            this.Num34.TabIndex = 11;
            this.Num34.Text = " 0000";
            this.Num34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num33
            // 
            this.Num33.AutoSize = true;
            this.Num33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num33.ForeColor = System.Drawing.Color.Maroon;
            this.Num33.Location = new System.Drawing.Point(116, 85);
            this.Num33.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num33.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num33.Name = "Num33";
            this.Num33.Size = new System.Drawing.Size(49, 18);
            this.Num33.TabIndex = 10;
            this.Num33.Text = " 0000";
            this.Num33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num32
            // 
            this.Num32.AutoSize = true;
            this.Num32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num32.ForeColor = System.Drawing.Color.Maroon;
            this.Num32.Location = new System.Drawing.Point(61, 85);
            this.Num32.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num32.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num32.Name = "Num32";
            this.Num32.Size = new System.Drawing.Size(49, 18);
            this.Num32.TabIndex = 9;
            this.Num32.Text = " 0000";
            this.Num32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num31
            // 
            this.Num31.AutoSize = true;
            this.Num31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num31.ForeColor = System.Drawing.Color.Maroon;
            this.Num31.Location = new System.Drawing.Point(6, 85);
            this.Num31.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num31.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num31.Name = "Num31";
            this.Num31.Size = new System.Drawing.Size(49, 18);
            this.Num31.TabIndex = 8;
            this.Num31.Text = " 0000";
            this.Num31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num44
            // 
            this.Num44.AutoSize = true;
            this.Num44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num44.ForeColor = System.Drawing.Color.Maroon;
            this.Num44.Location = new System.Drawing.Point(171, 115);
            this.Num44.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num44.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num44.Name = "Num44";
            this.Num44.Size = new System.Drawing.Size(49, 18);
            this.Num44.TabIndex = 15;
            this.Num44.Text = " 0000";
            this.Num44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num43
            // 
            this.Num43.AutoSize = true;
            this.Num43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num43.ForeColor = System.Drawing.Color.Maroon;
            this.Num43.Location = new System.Drawing.Point(116, 115);
            this.Num43.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num43.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num43.Name = "Num43";
            this.Num43.Size = new System.Drawing.Size(49, 18);
            this.Num43.TabIndex = 14;
            this.Num43.Text = " 0000";
            this.Num43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num42
            // 
            this.Num42.AutoSize = true;
            this.Num42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num42.ForeColor = System.Drawing.Color.Maroon;
            this.Num42.Location = new System.Drawing.Point(61, 115);
            this.Num42.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num42.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num42.Name = "Num42";
            this.Num42.Size = new System.Drawing.Size(49, 18);
            this.Num42.TabIndex = 13;
            this.Num42.Text = " 0000";
            this.Num42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Num41
            // 
            this.Num41.AutoSize = true;
            this.Num41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Num41.ForeColor = System.Drawing.Color.Maroon;
            this.Num41.Location = new System.Drawing.Point(6, 115);
            this.Num41.MaximumSize = new System.Drawing.Size(49, 18);
            this.Num41.MinimumSize = new System.Drawing.Size(49, 18);
            this.Num41.Name = "Num41";
            this.Num41.Size = new System.Drawing.Size(49, 18);
            this.Num41.TabIndex = 12;
            this.Num41.Text = " 0000";
            this.Num41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // arena
            // 
            this.arena.BackColor = System.Drawing.SystemColors.Control;
            this.arena.Controls.Add(this.Num34);
            this.arena.Controls.Add(this.Num44);
            this.arena.Controls.Add(this.Num11);
            this.arena.Controls.Add(this.Num43);
            this.arena.Controls.Add(this.Num12);
            this.arena.Controls.Add(this.Num42);
            this.arena.Controls.Add(this.Num13);
            this.arena.Controls.Add(this.Num41);
            this.arena.Controls.Add(this.Num14);
            this.arena.Controls.Add(this.Num21);
            this.arena.Controls.Add(this.Num33);
            this.arena.Controls.Add(this.Num22);
            this.arena.Controls.Add(this.Num32);
            this.arena.Controls.Add(this.Num23);
            this.arena.Controls.Add(this.Num31);
            this.arena.Controls.Add(this.Num24);
            this.arena.Location = new System.Drawing.Point(12, 12);
            this.arena.Name = "arena";
            this.arena.Size = new System.Drawing.Size(229, 156);
            this.arena.TabIndex = 16;
            this.arena.TabStop = false;
            this.arena.Text = "Game";
            this.arena.Enter += new System.EventHandler(this.arena_Enter);
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.Location = new System.Drawing.Point(12, 257);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(47, 13);
            this.scoreLabel.TabIndex = 17;
            this.scoreLabel.Text = "Score: 0";
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.startButton.ForeColor = System.Drawing.Color.Black;
            this.startButton.Location = new System.Drawing.Point(162, 260);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 23);
            this.startButton.TabIndex = 18;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            // 
            // highScoreLabel
            // 
            this.highScoreLabel.AutoSize = true;
            this.highScoreLabel.Location = new System.Drawing.Point(12, 270);
            this.highScoreLabel.Name = "highScoreLabel";
            this.highScoreLabel.Size = new System.Drawing.Size(69, 13);
            this.highScoreLabel.TabIndex = 19;
            this.highScoreLabel.Text = "HighScore: 0";
            // 
            // downButton
            // 
            this.downButton.Location = new System.Drawing.Point(88, 231);
            this.downButton.Name = "downButton";
            this.downButton.Size = new System.Drawing.Size(75, 23);
            this.downButton.TabIndex = 20;
            this.downButton.Text = "Down";
            this.downButton.UseVisualStyleBackColor = true;
            // 
            // rightButton
            // 
            this.rightButton.Location = new System.Drawing.Point(162, 203);
            this.rightButton.Name = "rightButton";
            this.rightButton.Size = new System.Drawing.Size(75, 23);
            this.rightButton.TabIndex = 21;
            this.rightButton.Text = "Right";
            this.rightButton.UseVisualStyleBackColor = true;
            // 
            // leftButton
            // 
            this.leftButton.Location = new System.Drawing.Point(12, 203);
            this.leftButton.Name = "leftButton";
            this.leftButton.Size = new System.Drawing.Size(75, 23);
            this.leftButton.TabIndex = 22;
            this.leftButton.Text = "Left";
            this.leftButton.UseVisualStyleBackColor = true;
            // 
            // upButton
            // 
            this.upButton.Location = new System.Drawing.Point(88, 174);
            this.upButton.Name = "upButton";
            this.upButton.Size = new System.Drawing.Size(75, 23);
            this.upButton.TabIndex = 23;
            this.upButton.Text = "Up";
            this.upButton.UseVisualStyleBackColor = true;
            this.upButton.Click += new System.EventHandler(this.upButton_Click);
            // 
            // GameForm
            // 
            this.AcceptButton = this.startButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(253, 292);
            this.Controls.Add(this.upButton);
            this.Controls.Add(this.leftButton);
            this.Controls.Add(this.rightButton);
            this.Controls.Add(this.downButton);
            this.Controls.Add(this.highScoreLabel);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.arena);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GameForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "2048-Form";
            this.arena.ResumeLayout(false);
            this.arena.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Num11;
        private System.Windows.Forms.Label Num12;
        private System.Windows.Forms.Label Num13;
        private System.Windows.Forms.Label Num14;
        private System.Windows.Forms.Label Num24;
        private System.Windows.Forms.Label Num23;
        private System.Windows.Forms.Label Num22;
        private System.Windows.Forms.Label Num21;
        private System.Windows.Forms.Label Num34;
        private System.Windows.Forms.Label Num33;
        private System.Windows.Forms.Label Num32;
        private System.Windows.Forms.Label Num31;
        private System.Windows.Forms.Label Num44;
        private System.Windows.Forms.Label Num43;
        private System.Windows.Forms.Label Num42;
        private System.Windows.Forms.Label Num41;
        private System.Windows.Forms.GroupBox arena;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label highScoreLabel;
        private System.Windows.Forms.Button downButton;
        private System.Windows.Forms.Button rightButton;
        private System.Windows.Forms.Button leftButton;
        private System.Windows.Forms.Button upButton;
    }
}

